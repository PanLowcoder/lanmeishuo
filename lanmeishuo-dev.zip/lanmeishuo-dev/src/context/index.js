import Taro, { createContext } from '@tarojs/taro'

export default DataContext = createContext()